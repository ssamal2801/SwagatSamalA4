﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Collections;
using System.Threading;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;

namespace Swagat_Samal_8711788_Assignment4
{
    [TestFixture]
    public class Class1
    {
        private IWebDriver driver;
        WebDriverWait wait;
        public IDictionary<string, object> vars {
            get; private set;
        }

        private IJavaScriptExecutor js;
        [SetUp]
        public void SetUp() {
            driver=new ChromeDriver();
            js=(IJavaScriptExecutor)driver;
            vars=new Dictionary<string, object>();
            wait=new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }
        [TearDown]
        protected void TearDown() {
            driver.Quit();
        }



        [Test]
        public void allFielsAreMandatory() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/index.html");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Please fill all the fields!"));
        }

        [Test]
        public void acceptablePhoneNumberFormat() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/index.html");
            driver.Manage().Window.Size=new System.Drawing.Size(1286, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("Swagat");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("14 Beachsurf Rd");
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Ontario']")).Click();
            }
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Vancouver']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("226-504034");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("ssamal1877@conestogac.on.ca");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Sample Note");
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Acceptable formats: 123-123-1234, or (123)123-1234"));
        }

        [Test]
        public void acceptableZipCodeFormat() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1286, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("Swagat");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("14 Beachsurf Road");
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Ottawa']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Ontario']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("asddfd");
            driver.FindElement(By.Name("phone")).SendKeys("226-507-4034");
            driver.FindElement(By.Name("email")).SendKeys("ssamal1877@conestogac.on.ca");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("226-507-4034");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Sample Comment");
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Postal Code (Acceptable format: NAN ANA – where 'A' is any alphabetic character and 'N' is avalid numeric digit)"));
        }

        [Test]
        public void emailFormatCheck() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("Swagt");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("14 Beachsurf Road");
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Montréal']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Manitoba']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("223-454-6565");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("swagat");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Test Note");
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Email should be in format \'example@smail.com\'"));
        }

        [Test]
        public void formValidationPassCaseWelcomesUser() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("Swagat");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("25 Islington St");
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Toronto']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Ontario']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("252-654-6549");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("swagat@gmail.com");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Final Note");
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Welcome! You are a member now."));
        }

        [Test]
        public void deleteImmediateRecordTest() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("Swagat");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("25 Islington St");
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Toronto']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Ontario']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("252-654-6549");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("swagat@gmail.com");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Final Note");
            driver.FindElement(By.Id("register")).Click();
            driver.SwitchTo().Alert().Accept();
            driver.FindElement(By.LinkText("View Record")).Click();
            driver.FindElement(By.Id("delete")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Record deleted!"));
        }

        //Pre-requisite: Delete all users before starting.
        //View record link shows the latest user registered on the app
        [Test]
        public void ifNotRegisteredAlertUserOnClickOfViewRecord() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Id("viewRecord")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("No Records Found"));
        }

        //Pre-requisite: Delete all users before starting.
        [Test]
        public void alertMessageForNoPastResistrationsFound() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.LinkText("Search")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("No Records Found"));
        }

        [Test]
        public void viewRecordShowsLastSavedRecord() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);

            var fname = "Swagat";
            var lname = "Samal";
            var address = "25 Islington St";

            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys(fname);
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys(lname);
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys(address);
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Toronto']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Ontario']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("252-654-6549");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("swagat@gmail.com");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Final Note");
            driver.FindElement(By.Id("register")).Click();
            driver.SwitchTo().Alert().Accept();

            driver.FindElement(By.Id("viewRecord")).Click();
            Assert.AreEqual(driver.FindElement(By.Id("contact")).Text,fname + " "+lname);
            Assert.AreEqual(driver.FindElement(By.Id("address")).Text, address);
        }

        [Test]
        public void nameFormatCheck() {
            driver.Navigate().GoToUrl("http://127.0.0.1:5500/");
            driver.Manage().Window.Size=new System.Drawing.Size(1346, 748);
            driver.FindElement(By.Name("fname")).Click();
            driver.FindElement(By.Name("fname")).SendKeys("7878");
            driver.FindElement(By.Name("lname")).Click();
            driver.FindElement(By.Name("lname")).SendKeys("Samal");
            driver.FindElement(By.Name("address")).Click();
            driver.FindElement(By.Name("address")).SendKeys("14 Maddock Rd");
            driver.FindElement(By.Name("city")).Click();
            {
                var dropdown = driver.FindElement(By.Name("city"));
                dropdown.FindElement(By.XPath("//option[. = 'Toronto']")).Click();
            }
            driver.FindElement(By.Name("province")).Click();
            {
                var dropdown = driver.FindElement(By.Name("province"));
                dropdown.FindElement(By.XPath("//option[. = 'Alberta']")).Click();
            }
            driver.FindElement(By.Name("pcode")).Click();
            driver.FindElement(By.Name("pcode")).SendKeys("2M1L6R");
            driver.FindElement(By.Name("phone")).Click();
            driver.FindElement(By.Name("phone")).SendKeys("226-898-5656");
            driver.FindElement(By.Name("email")).Click();
            driver.FindElement(By.Name("email")).SendKeys("sinu@gmail.com");
            driver.FindElement(By.Name("notes")).Click();
            driver.FindElement(By.Name("notes")).SendKeys("Note");
            driver.FindElement(By.Id("register")).Click();
            Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Incorect name format"));
        }

    }
}
